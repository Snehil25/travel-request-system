package com.tx.employee_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
