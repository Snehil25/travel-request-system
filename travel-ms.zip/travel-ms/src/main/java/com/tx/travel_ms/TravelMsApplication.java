package com.tx.travel_ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelMsApplication.class, args);
	}

}
